#!/usr/bin/env bash
set -e # halt script on error

rake

bundle install